GBFR STORY COMPLETE WORKER v1.8 - FINAL RECOVERY HOTFIX
======================================================

NGUYEN NHAN V1.7 DUNG SAU BATCH 12/12
- V1.7 da khoa dung 63 metadata TXT_CV va pilot dat 100/102 = 98%.
- Hai muc pilot con lai bi Qwen chen CJK lap lai: AUX-STAGE-0497 va
  AUX-STAGE-0590.
- Batch cuoi dat 8/10; AUX-STAGE-1473 van giu nguyen English, con
  AUX-STAGE-1480 bi QA bao nham TECHNICAL_TOKEN_MISMATCH.
- Regex printf cu xem cum "{0:100}% dua tren" la token "% d", trong khi
  English source khong co token do.
- Sau batch 12/12 khong con du lieu moi de bao ve, nhung cong ty le 1% van
  dung Worker truoc khi no co the vao hang cuu ky thuat.

V1.8 THAY DOI GI
- Loai bo khoang trang khoi flag printf cua Story Worker. Toan bo corpus
  20.492 muc khong co source token printf dang "% d"; placeholder compact
  nhu %d/%s van duoc bao ve.
- Khong ap dung EARLY_RECOVERY_GROWTH/UNRESOLVED_RATE_TOO_HIGH sau batch moi
  cuoi cung. Structured failure va batch-wide failure van giu cong bao ve.
- Cac muc chua dat duoc chuyen vao dung hang cuu nhom/cuu le. Neu van that
  bai, Worker ghi TECHNICAL_ERROR va giu English fallback de hoan tat corpus.
- Giu toan bo sua loi v1.5-v1.7, bao gom checkpoint, failure-log backlog,
  English-only CJK repair, TXT_CV exact English, dau "...", am thanh phi
  ngon ngu, 5,000 = 5.000 va alias Grandcypher co gioi han.

CACH CAP NHAT
1. Dong cua so Worker v1.7 dang hien "Press any key to continue".
2. Giai nen ZIP nay vao thu muc cha dang chua
   GBFR_Story_Complete_Worker_v1.
3. Chon Replace the files in the destination.
4. KHONG xoa progress va KHONG xoa data.
5. Giu LM Studio dang bat Qwen3.5 9B, Local Server cong 1234.
6. Chay lai 01_CHAY_DICH_STORY_COMPLETE.cmd.

DAU HIEU DUNG
- Dong dau: GBFR Story Complete Worker v1.8.
- Worker du kien khong con fresh pilot; no se vao thang:
  "Bat dau hang cuu ky thuat: ... muc."
- So luong hang cuu co the khoang 179 muc tuy checkpoint thuc te.
- Khi xong, Worker tao GBFR_Story_Translation_Result_v1.zip va
  progress\story_translation_report.json.

CHECKPOINT VA KET QUA
- Khong xoa ban dich hop le, raw EN/JP, progress hoac data.
- LOCAL_OK/REVIEW chi la QA ky thuat, chua phai APPROVED.
- TECHNICAL_ERROR duoc giu English fallback va dua vao Hybrid QA sau baseline.
